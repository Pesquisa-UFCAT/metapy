"""Objective function"""
from metapy_toolbox import loss_function_mse

def my_obj_function(x, none_variable):
    x_0 = x[0]
    x_1 = x[1]
    obj_fun = x_0 ** 2 + x_1 ** 2
    return obj_fun


def idf(a, b, c, k, t_r, t_c):
    return (k * t_r ** a) / (t_c + b) ** c


def my_obj_function2(x, none_variable):

    # External IDF dataset
    df = none_variable

    # Design variables
    a = x[0]
    b = x[1]
    c = x[2]
    k = x[3]

    # Start internal variables
    y_true = []
    y_pred = []

    # Read dataset and idf evaluation
    for _, row in df.iterrows():
        t_r = row['T_R']
        t_c = row['T_C']
        y_true.append(row['Y_EXP'])
        y_pred.append(idf(a, b, c, k, t_r, t_c))

    mse = loss_function_mse(y_true, y_pred)
    of = mse

    return of
# # Derivatives of the objective function
# def MY_FUNCTION_DERIVATIVE(X, NULL_DIC):
#     X_0 = X[0]
#     X_1 = X[1]
#     OF_DIFF_0 = 24 * X_0 - 12 * X_1 + 2
#     OF_DIFF_1 = 8 * X_1 - 12 * X_0
#     OF_DIFF = [OF_DIFF_0, OF_DIFF_1]
#     return OF_DIFF


# def MY_FUNCTION_TSP(X, NULL_DIC):
#     """
#     https://people.sc.fsu.edu/~jburkardt/datasets/tsp/tsp.html
#     """
#     COST = [[0.0, 3.0, 4.0, 2.0, 7.0],
#             [3.0, 0.0, 4.0, 6.0, 3.0],
#             [4.0, 4.0, 0.0, 5.0, 8.0],
#             [2.0, 6.0, 5.0, 0.0, 6.0],
#             [7.0, 3.0, 8.0, 6.0, 0.0]]
#     ROUTE = list(X.copy())
#     OF = 0
#     for NODE in range(len(ROUTE)):
#         I = int(ROUTE[NODE])
#         if NODE == len(ROUTE) - 1:
#             J = int(ROUTE[0])
#         else:
#             J = int(ROUTE[NODE + 1])
#         OF += COST[I][J]
#     return OF


# def KNAPSACK(X, INSTANCE):
#     """
#     Input:
#     X
#     INSTANCE  |  Instance tag      |     | String
#     X         |  Design variables  |     | Py List
    
#     Output
#     G         |  Constraints       |  $  | Float
#     OF        |  Profit            |  $  | Float
#     """
    
#     if INSTANCE == 'LETS':
#         PROFIT = [5.0, 5.5, 7.5, 4.0, 4.5, 3.0, 6.0, 5.8, 6.2, 3.5, 1.0, 4.2, 6.5]
#         COST =   [5.0, 4.5, 2.5, 6.0, 5.5, 7.0, 4.0, 4.2, 3.8, 6.5, 9.0, 5.8, 3.5]
#         COST_MAX = 25.0
#         D = 13

#     OF = 0
#     G = 0
    
#     for I in range(len(PROFIT)):
#         OF += X[I] * PROFIT[I]
#         G += X[I] * COST[I]

#     OF *= -1
#     COST_VALUE = G
#     G -= COST_MAX
    
#     return COST_VALUE, G, OF

# def LETS_MAKE(X, NULL_DIC):
#     DISCRETE_DATA = NULL_DIC['X']
#     D = len(DISCRETE_DATA)
#     X_NEW = CONVERT_CONTINUOUS_DISCRETE(X, DISCRETE_DATA)
#     _, G_0, OF = KNAPSACK(X_NEW, NULL_DIC['INSTANCE'])
#     PSEUDO_OF = OF + (np.maximum(0, G_0)) * NULL_DIC['R_P']
    
#     return PSEUDO_OF