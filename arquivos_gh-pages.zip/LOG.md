<!--Don't delete ths script-->
<script src = "https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
<script id = "MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
<!--Don't delete ths script-->

<h1>LOG</h1>

<p align = "justify">
Version log file.
</p>

<h2>2023.1</h2>

<p align = "justify">
Firefly algorithm.
</p>

<h2>2022.2</h2>

<p align = "justify">
Simulated Annealing algorithm.
</p>


<h2>2022.1</h2>

<p align = "justify">
Hill Climbing algorithm.
</p>
