---
layout: default
title: Mathematical Functions
parent: Benchmark
nav_order: 1
has_children: true
has_toc: true
---

<!--Don't delete ths script-->
<script src = "https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
<script id = "MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
<!--Don't delete ths script-->

<p align = "justify">
    This section describes the documentation of benchmark functions implemented in the METApy framework.
</p>
