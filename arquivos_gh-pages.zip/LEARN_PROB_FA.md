<!-- ---
layout: default
title: Standard Firefly
parent: Probabilistic
grand_parent: Learning
nav_order: 6
has_children: true
has_toc: true
--- -->

<!--Don't delete ths script-->
<script src = "https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
<script id = "MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
<!--Don't delete ths script-->

<p align = "justify">
    This section presents an review of the optimization methods and their applications.
</p>
