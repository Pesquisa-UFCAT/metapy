---
layout: default
title: Release notes
nav_order: 20
---

<!--Don't delete ths script-->
<script src = "https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
<script id = "MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
<!--Don't delete ths script-->

2023.4.7
{: .label .label-blue }

<ul>
  <li>first version</li>
  <li>algorithms: <code>hill_climbing_01</code></li>
</ul>   
