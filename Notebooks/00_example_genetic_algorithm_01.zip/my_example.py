"""Objective function"""

def my_obj_function(x, none_variable):
    x_0 = x[0]
    x_1 = x[1]
    obj_fun = x_0 ** 2 + x_1 ** 2
    return obj_fun
