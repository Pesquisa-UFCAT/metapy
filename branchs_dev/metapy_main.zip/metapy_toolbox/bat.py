"""bat algorithm functions"""
# https://link.springer.com/article/10.1007/s11831-022-09817-5
# https://medium.com/it-paragon/bat-algorithm-bad-algorithm-b26ae42da8e1