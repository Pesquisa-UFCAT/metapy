coverage run -m unittest <nome_do_arquivo_de_teste>

coverage run -m unittest test_calculadora.py

coverage report -m
