import sys

# Change the path in other computer
#TEST_FOLDER = r'C:\Users\wander\Documents\GitHub\METAPYDEV\META_TOOLBOX'
#TEST_FOLDER = '/home/mateus/Documents/Estágio/META/METAPYDEV/META_TOOLBOX'
#sys.path.append(TEST_FOLDER)
import sys
TEST_FOLDER = '/home/mateus/Documents/Estágio/META/METAPYDEV/META_TOOLBOX'
sys.path.append(TEST_FOLDER)

# Module import
from META_GA_LIBRARY import *

