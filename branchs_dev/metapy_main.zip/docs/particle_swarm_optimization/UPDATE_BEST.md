---
layout: default
title: UPDATE_BEST
grand_parent: Framework
parent: Common Library functions
nav_order: 2
has_toc: false
---

<h3>UPDATE_BEST</h3>

<br>

<p align = "justify">
    </p>

```python
UPDATE_BEST(X, X_BEST, Y, Y_BEST)
```

Input variables
{: .label .label-yellow }

<table style = "width:100%">
    <thead>
      <tr>
        <th>Name</th>
        <th>Description</th>
        <th>Type</th>
      </tr>
    </thead>
    <tr>
        <td><code>X</code></td>
        <td>Description not available.</td>
        <td>None</td>
    </tr>
    <tr>
        <td><code>X_BEST</code></td>
        <td>Description not available.</td>
        <td>None</td>
    </tr>
    <tr>
        <td><code>Y</code></td>
        <td>Description not available.</td>
        <td>None</td>
    </tr>
    <tr>
        <td><code>Y_BEST</code></td>
        <td>Description not available.</td>
        <td>None</td>
    </tr>
</table>

Output variables
{: .label .label-yellow }

<table style = "width:100%">
    <thead>
      <tr>
        <th>Name</th>
        <th>Description</th>
        <th>Type</th>
      </tr>
    </thead>
    <tr>
        <td><code>None</code></td>
        <td>The function displays the plot on the screen and saves it to the local folder of the <code>.ipynb</td>
        <td>None</td>
    </tr>
</table>

Example 1
{: .label .label-blue }

<p align = "justify">
    <i>
        Use the <code>UPDATE_BEST</code> function to perform a task.
    </i>
</p>

```python
# Example code goes here
```

```bash
# Example output goes here
```

