"""Objective function"""

def markowitz_mean_variance_model(x, none_variable):
  
    
    return of
