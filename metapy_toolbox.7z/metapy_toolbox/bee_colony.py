"""bee colony algorithm functions"""
# https://sci-hub.wf/10.1016/j.knosys.2019.105002 melhor deles
# https://sci-hub.wf/10.1016/j.istruc.2021.01.016
# https://sci-hub.wf/10.1016/j.cam.2020.113199
# https://sci-hub.wf/10.1016/j.asoc.2020.106391